#ifndef TREEHEAP
#define TREEHEAP

#include "value.h"
#include "ResultTree.h"

// ������Ķ�
class TreeHeap
{
private:
	ResultTree *heap[MAXTREE];
	ResultTree *tab[NHASH];
	int tot;

public:
	TreeHeap();
	~TreeHeap();
	void up( int p );
	void down( int p );
	ResultTree *removeMin();
	void add( ResultTree *now );
	ResultTree *find( ResultTree *now );
	int size();
};


#endif