#include "StateHeap.h"

extern State h[MAXHEAPS];

inline bool operator<(const State &s1,const State &s2)
{
	return s1.p->mt[s1.s]<s2.p->mt[s2.s];
}

StateHeap::StateHeap()
{
	tot=0;
}

void StateHeap::init()
{
	tot=0;
}

template<class T>
void swap(T &a,T &b)
{
	T c=a;

	a=b;
	b=c;
}

/*
void StateHeap::push(State &s)
{
	int i,j;

	if (tot==MAXHEAPS)
		return;

	h[tot]=s;
	h[tot].p->ind[h[tot].s]=tot;
	for (i=tot; i>0; i=j)
	{
		j=(i-1)/2;
		//if (h[i]<h[j])
		if (h[i].p->mt[h[i].s]<h[j].p->mt[h[j].s])
		{
			swap(h[i],h[j]);
			swap(h[i].p->ind[h[i].s],h[j].p->ind[h[j].s]);
		}
		else
			break;
	}
	tot++;
}
*/

void StateHeap::push(State &s)
{
	int i,j;
	State temp;
	SCORETYPE temps;

	if (tot==MAXHEAPS)
		return;

	temp=s;
	temps=temp.p->mt[temp.s];

	for (i=tot; i>0; i=j)
	{
		j=((i-1)>>1);
		if (temps<h[j].p->mt[h[j].s])
		{
			h[i]=h[j];
			h[i].p->ind[h[i].s]=i;
		}
		else
			break;
	}
	h[i]=temp;
	h[i].p->ind[h[i].s]=i;

	tot++;
}

bool StateHeap::isEmpty()
{
	return tot==0;
}

/*
void StateHeap::update(int ind)
{
	int i,j;

	for (i=ind; i>0; i=j)
	{
		j=(i-1)/2;
		//if (h[i]<h[j])
		if (h[i].p->mt[h[i].s]<h[j].p->mt[h[j].s])
		{
			swap(h[i],h[j]);
			swap(h[i].p->ind[h[i].s],h[j].p->ind[h[j].s]);
		}
		else
			break;
	}
}	
*/

void StateHeap::update(int ind)
{
	int i,j;
	State temp;
	SCORETYPE temps;

	temp=h[ind];
	temps=temp.p->mt[temp.s];

	for (i=ind; i>0; i=j)
	{
		j=((i-1)>>1);
		if (temps<h[j].p->mt[h[j].s])
		{
			h[i]=h[j];
			h[i].p->ind[h[i].s]=i;
		}
		else
			break;
	}
	h[i]=temp;
	h[i].p->ind[h[i].s]=i;
}	

State StateHeap::top()
{
	return h[0];
}

/*
State StateHeap::pop()
{
	State rtn=h[0];
	int i,j;

	h[0].p->ind[h[0].s]=-1;
	h[0]=h[tot-1];
	h[0].p->ind[h[0].s]=0;
	tot--;

	for (i=0; i*2+1<tot; i=j)
	{
		j=i*2+1;
		if (j+1<tot)
			//if (h[j+1]<h[j])
			if (h[j+1].p->mt[h[j+1].s]<h[j].p->mt[h[j].s])
				j++;
		//if (h[j]<h[i])
		if (h[i].p->mt[h[i].s]>h[j].p->mt[h[j].s])
		{
			swap(h[i],h[j]);
			swap(h[i].p->ind[h[i].s],h[j].p->ind[h[j].s]);
		}
		else
			break;
	}
	return rtn;
}
*/

State StateHeap::pop()
{
	State rtn=h[0];
	int i,j;
	State temp;
	SCORETYPE temps;

	h[0].p->ind[h[0].s]=-1;

	h[0]=h[tot-1];
	h[0].p->ind[h[0].s]=0;
	temp=h[0];
	temps=temp.p->mt[temp.s];

	tot--;

	for (i=0; i*2+1<tot; i=j)
	{
		j=(i<<1)+1;
		if (j+1<tot)
			//if (h[j+1]<h[j])
			if (h[j+1].p->mt[h[j+1].s]<h[j].p->mt[h[j].s])
				j++;
		//if (h[j]<h[i])
		if (temps>h[j].p->mt[h[j].s])
		{
			h[i]=h[j];
			h[i].p->ind[h[i].s]=i;
		}
		else
			break;
	}
	h[i]=temp;
	h[i].p->ind[h[i].s]=i;

	return rtn;
}
