#ifndef NODEHASH
#define NODEHASH

#include "value.h"
#include "struct.h"

// ͨ������pֵ(����)����hash��

class HashNode
{
public:
	Node *node;
	HashNode *next;
};

class NodeHash
{
private:
	HashNode *tab[NHASH];
public:
	NodeHash();
	~NodeHash();
	Node *find( Node *nod );
	void add( Node *nod );
};

#endif