#include <string.h>
#include "NodeHash.h"
#include "struct.h"

NodeHash::NodeHash()
{
	memset( tab, 0, sizeof( tab ) );
}

Node* NodeHash::find( Node* nod )
{
	int h = nod->p % NHASH;
	for( HashNode *now = tab[h]; now; now = now->next )
		if( now->node->p == nod->p )
			return now->node;
	return NULL;
}

void NodeHash::add( Node *nod )
{
	HashNode *now = new HashNode();
	now->node = nod;
	int h = nod->p % NHASH;
	now->next = tab[h];
	tab[h] = now;
}

NodeHash::~NodeHash()
{
	for( int i = 0; i < NHASH; ++i )
	{
		HashNode *now = tab[i];
		while( now )
		{
			HashNode *pre = now;
			now = now->next;
			delete pre;
		}
	}
}