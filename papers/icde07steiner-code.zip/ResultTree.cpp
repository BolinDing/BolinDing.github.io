#include "struct.h"
#include "ResultTree.h"
#include <stdio.h>

extern FILE *fresult;

ResultTree::ResultTree()
{
	n = 0;
	h = -1;
	cost = 0;
}

void ResultTree::add( Node *n1, Node *n2 )
{
	for( int i = 0; i < n; ++i )
		if( ( p1[i] == n1 && p2[i] == n2 ) ||
			( p1[i] == n2 && p2[i] == n1 ) )
			return;
	p1[n] = n1;
	p2[n] = n2;
	cost += 1.0;
	++n;
}

unsigned ResultTree::hash()
{
	if( h == -1 )
	{
		int i, j;
		h = 0;
		for( i = 0; i < n; ++i )
		{
			Node *p1i = p1[i];
			Node *p2i = p2[i];
			if( p1i->p > p2i->p )
			{
				Node *tmp = p1i;
				p1i = p2i;
				p2i = tmp;
			}
			for( j = i + 1; j < n; ++j )
			{
				Node *p1j = p1[j];
				Node *p2j = p2[j];
				if( p1j->p > p2j->p )
				{
					Node *tmp = p1j;
					p1j = p2j;
					p2j = tmp;
				}
				if( p1i->p < p1j->p || ( p1i->p == p1j->p && p2i->p < p2j->p ) )
				{
					Node *tmp = p1[i];
					p1[i] = p1[j];
					p1[j] = tmp;
					tmp = p2[i];
					p2[i] = p2[j];
					p2[j] = tmp;
				}
			}
		}
		for( i = 0; i < n; ++i )
			if( p1[i]->p < p2[i]->p )
				h = ( h * MUL + p1[i]->p ) * MUL + p2[i]->p;
			else
				h = ( h * MUL + p2[i]->p ) * MUL + p1[i]->p;
		h = ( ( unsigned ) h ) % NHASH;
	}
	return h;
}

bool ResultTree::equals( ResultTree *r )
{
	if( n != r->n )
		return false;
	for( int i = 0; i < n; ++i )
	{
		if( p1[i] == r->p1[i] && p2[i] == r->p2[i] )
			continue;
		if( p1[i] == r->p2[i] && p2[i] == r->p1[i] )
			continue;
		return false;
	}
	return true;
}

void ResultTree::print()
{
	fprintf( fresult, "cost=%0.5lf\n", cost );
	fprintf( fresult, "edge number=%d\n", n );
	fprintf( fresult, "root=%d\n", root->p );
	if( n == 0 )
		fprintf( fresult, "%d\n", root->p );
	else
	{
		for( int i = 0; i < n; ++i )
			fprintf( fresult, "(%d,%d)", p1[i]->p, p2[i]->p );
		fprintf( fresult, "\n" );
	}
	printf( "end of tree\n" );
	fprintf( fresult, "==============================================================\n\n" );
}