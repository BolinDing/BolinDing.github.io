#ifndef STATEHEAP
#define STATEHEAP

#include "struct.h"
#include "value.h"

struct State
{
	Node* p;
	char  s;
	State() {};
	State(Node* p,char s):p(p),s(s) {};
};

class StateHeap{
private:
	int tot;

public:
	StateHeap();
	void init();
	void push(State &s);
	State pop();
	State top();
	void update(int ind);
	bool isEmpty();
};

#endif