#ifndef NODEINDEXHEAP
#define NODEINDEXHEAP

#include "struct.h"
#include "value.h"
#include "NodeHash.h"

class IndexHeapNode
{
public:
	int index;
	Node *node;
	IndexHeapNode *next;
};

// ��¼index�����ѣ�֧��update������
class NodeIndexHeap
{
private:
	int tot;
	IndexHeapNode *heap[MAXHEAP];
	IndexHeapNode *tab[NHASH];

public:
	NodeIndexHeap();
	~NodeIndexHeap();
	void up( int p );
	void down( int p );
	void add( Node *nod );
	bool isEmpty();
	IndexHeapNode* find( Node *nod );
	Node *getMin();
	Node *removeMin();
	void update( Node *nod );
};

#endif