#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "struct.h"
#include "value.h"
#include "NodeHash.h"
#include "StateHeap.h"

// ����Ĺؼ��ּ���
char K[MAXKEYNUM][MAXKEYLEN];

// �ؼ��ֵĸ���
int n;
int nn;
// �ؼ��ֽ��ĸ���
int m;
// �ؼ��ֽ�㼯��
Node *S[MAXKEYNOD];
// �ؼ��ֽ�㰴�չؼ��ֻ��ֵĽ���
int lim[MAXKEYNUM];

// ���еĽ��
Node nod[MAXNOD];
// ���ĸ���
int nodnum;

// ���еı�
Edge edg[MAXEDGE];
// �ߵĸ���
int edgnum;

// ����hash����ͨ��rowid���ҽ��
Node *tab[NHASH];

// �ؼ����ļ�
FILE *fquery;

// ����ļ�
FILE *fresult;

FILE *ftime;

FILE *frun;

char _frun[MAXNAME];
char _fgraph[MAXNAME];
char _fstring[MAXNAME];
char _fquery[MAXNAME];
char _fresult[MAXNAME];
char _ftime[MAXNAME];

int testcase;

// ͨ��rowid�õ��ؼ���
Node *findIt( char* st )
{
	unsigned h = 0;
	for( char *ch = st; *ch; ++ch )
		h = h * MUL + *ch;
	h %= NHASH;
	Node *now;
	for( now = tab[h]; now; now = now->next )
		if( strcmp( now->rowid, st ) == 0 )
			return now;
	now = &nod[nodnum];
	strcpy( now->rowid, st );
	now->p = nodnum;
	now->next = tab[h];
	tab[h] = now;
	now->score = 1.0;
	++nodnum;
	return now;
}

// ��datagraph�ж���ͼ����Ϣ
void readIn()
{
	char st[MAXST];
	char s1[MAXNAME];
	char s2[MAXNAME];

	memset( tab, 0, sizeof( tab ) );
	memset( nod, 0, sizeof( nod ) );
	FILE *fin = fopen( _fgraph, "r" );

	testcase = 0;
	nodnum = 0;
	edgnum = 0;
	while( fscanf( fin, "%s %s %s %s", st, s1, st, s2 ) != EOF )
	{
		Node *p1 = findIt( s1 );
		Node *p2 = findIt( s2 );
		Edge *e;
		
		p1->degree++;
		p2->degree++;

		e=&edg[edgnum++];
		e->node=p2;
		e->next=p1->edge;
		p1->edge=e;
		e->forward=true;

		e=&edg[edgnum++];
		e->node=p1;
		e->next=p2->edge;
		p2->edge=e;
		e->forward=false;
	}

	// ����ÿ���ߵķ���
	for( int i = 0; i < nodnum; ++i )
	{
		Edge *e;

		for (e=nod[i].edge; e; e=e->next)
			if( ! e->forward )
				e->weight = (SCORETYPE) 1.0;
			else
				e->weight = (SCORETYPE) 1.0 * log( (double) 1.0 + (double) nod[i].degree ) / log( 2.0 );
	}

	fclose( fin );
	
	fin = fopen( _fstring, "r" );
	while( fgets( st, MAXST, fin ) )
	{
		int pos = 0;
		while( st[pos] != ' ' )
			++pos;
		st[pos] = '\0';
		findIt( st );
	}
	fclose( fin );

	fquery = fopen( _fquery, "r" );

	fresult = fopen( _fresult, "w" );

	ftime = fopen( _ftime, "w" );

}

// �õ��ؼ��ֽ��
bool getKey()
{
	char st[MAXST];
	int i,j;

	if( !fgets( st, MAXST, fquery ) )
		return false;
	for (i=0; i<(int)strlen(st); i++)
		if (st[i]=='\n')
			st[i]=0;
	for (i=0; i<(int)strlen(st); i++)
		if (st[i]>='A'&&st[i]<='Z')
			st[i]=st[i]-'A'+'a';

	fprintf( fresult, "Test data %d:%s\n", ++testcase, st );
	n = 0;
	int pre = 0, pos = 0;
	bool flag = true;
	while( flag )
	{
		while( st[pos] != ' ' && st[pos] != '\n' && st[pos] )
			++pos;
		if( st[pos] == '\n' || st[pos] == '\0' )
			flag = false;
		st[pos] = '\0';
		if (strlen(st+pre)>0)
		{
			strcpy( K[n++], st + pre );
			pre = ++pos;
		}
	}
	nn=(1<<n);

	memset( lim, 0, sizeof( lim ) );
	pre = 0;
	for( i = 0; i < n; ++i )
	{
		FILE *fin = fopen( _fstring, "r" );

		while( fgets( st, MAXST, fin ) )
		{
			pos = 0;
			while( st[pos] != ' ' )
				++pos;

			for (j=pos; j<(int)strlen(st); j++)
				if (st[j]>='A'&&st[j]<='Z')
					st[j]=st[j]-'A'+'a';

			st[pos] = '\0';

			if( strstr( st + pos + 1, K[i] ) )
			{
				Node *now = findIt( st );
				S[pre++] = now;
			}
		}
		lim[i] = pre;
		fprintf(fresult,"%d ",lim[i]);
		fclose( fin );
	}
	m = pre;
	fprintf(fresult,"\n");
	return true;
}

void closeIt()
{
	fclose( fresult );
	fclose( fquery );
	fclose( ftime );
}

////////////////////////////////DETECTOR//////////////////////////////////

//״̬��
State h[MAXHEAPS];
StateHeap queue;

//����״̬
char NS[MAXKEYPOW][MAXKEYPOW];
int nNS[MAXKEYPOW];

//Time
int stime[TOPK],ttime[TOPK];
//Expanded Nodes
int sexnd[TOPK],texnd[TOPK];
//Score
SCORETYPE sscor[TOPK],tscor[TOPK];
//Testdata
int testdata,k;

int ad[TOPK];
char a1[TOPK][MAXTREE][MAXROWID];
char a2[TOPK][MAXTREE][MAXROWID];

void DETECTOR_gettree(Node* r,char s)
{
	if (r->suf[s])
	{
		strcpy(a1[k][ad[k]],r->rowid);
		strcpy(a2[k][ad[k]],r->suf[s]->rowid);
		ad[k]++;
		DETECTOR_gettree(r->suf[s],s);
	}
	else if (r->pat[s])
	{
		DETECTOR_gettree(r,r->pat[s]);
		DETECTOR_gettree(r,s^(r->pat[s]));
	}
	else
		return;
}

int DETECTOR_sametree(int t1,int t2)
{
	int i,j;

	if (ad[t1]==ad[t2])
	{
		for(i=0; i<ad[t1]; i++)
		{
			for (j=0; j<ad[t2]; j++)
			{
				if (strcmp(a1[t1][i],a1[t2][j])==0&&strcmp(a2[t1][i],a2[t2][j])==0)
					break;
				if (strcmp(a2[t1][i],a1[t2][j])==0&&strcmp(a1[t1][i],a2[t2][j])==0)
					break;
			}
			if (j==ad[t2])
				return 0;
		}
		return 1;
	}
	else
		return 0;
}

int DETECTOR_existtree()
{
	int i;

	for (i=0; i<k; i++)
		if (DETECTOR_sametree(i,k))
			return 1;
	return 0;
}



/*
void DETECTOR_newnode(Node *p)
{
	//int i;

	sexnd[k]++;								//PERFORMANCE

	p->mt=new SCORETYPE[nn];
	//for (i=0; i<(nn); i++)
	//	p->mt[i]=NA;
	memset(p->mt,-1,sizeof(SCORETYPE)*(nn));

	p->suf=new Node*[nn];
	memset(p->suf,0,sizeof(Node*)*(nn));

	p->pat=new char[nn];
	memset(p->pat,0,sizeof(char)*(nn));
	
	p->ind=new int[nn];
	memset(p->ind,-1,sizeof(int)*(nn));	
}
*/

void DETECTOR_init()
{
	int i,j,pre;
	char s1,s2;

	memset(nNS,0,sizeof(nNS));
	for (s1=0; s1<(nn); s1++)
		for (s2=1; s2<(nn); s2++)
			if (!(s1&s2))
				NS[s1][nNS[s1]++]=s2;

	queue.init();

	for (i=0; i<nodnum; i++)
	{
		/*
		nod[i].mt=0;
		nod[i].suf=0;
		nod[i].pat=0;
		nod[i].ind=0;
		*/
		
		for (j=0; j<nn; j++)
			nod[i].mt[j]=NA;
		memset(nod[i].suf,0,sizeof(Node*)*(nn));
		memset(nod[i].pat,0,sizeof(char)*(nn));
		memset(nod[i].ind,-1,sizeof(int)*(nn));
	}
	
	pre=0;
	for (i=0; i<n; i++)
	{
		for (j=pre; j<lim[i]; j++)
			(S[j]->ini)|=(1<<i);
		pre=lim[i];
	}

	for (i=0; i<nodnum; i++)
		if (nod[i].ini!=0)
		{
			//DETECTOR_newnode(nod+i);
			nod[i].mt[nod[i].ini]=0;
			queue.push(State(nod+i,nod[i].ini));
		}
}

void DETECTOR_clear()
{
	int i;

	
	for (i=0; i<nodnum; i++)
	{
		nod[i].ini=0;
		nod[i].vis=0;					//PERFORMANCE
		/*
		if (nod[i].mt)
		{
			delete nod[i].mt;
			delete nod[i].suf;
			delete nod[i].pat;
			delete nod[i].ind;
		}
		*/
	}
}

int n_edge;
void DETECTOR_print(Node* r,char s,int sp)
{
	int i;

	if (r->suf[s])
	{
		n_edge++;
		for (i=0; i<sp+1; i++)
			fprintf(fresult," ");
		fprintf(fresult,"%s %s\n",r->rowid,r->suf[s]->rowid);
		DETECTOR_print(r->suf[s],s,sp+1);
	}
	else if (r->pat[s])
	{
		DETECTOR_print(r,r->pat[s],sp);
		DETECTOR_print(r,s^(r->pat[s]),sp);
	}
	else
		return;
}

void DETECTOR_output(Node* r,char s,int k,int res_time)
{
//	int i,j;

	stime[k]=res_time;									//PERFORMANCE
	sscor[k]=r->mt[s];									//PERFORMANCE

	/*
	for (i=0; i<nodnum; i++)						//PERFORMANCE
	{												//PERFORMANCE
		for (j=0; j<nn; j++)						//PERFORMANCE
			if (nod[i].mt[j]!=NA)					//PERFORMANCE
				break;								//PERFORMANCE
		if (j<nn)									//PERFORMANCE
			sexnd++;								//PERFORMANCE
	}
	*/

	if (k>0)												//PERFORMANCE
		sexnd[k]+=sexnd[k-1];								//PERFORMANCE

	fprintf(ftime,"%d %d %d\n",stime[k],sexnd[k],sscor[k]);	//PERFORMANCE
	ttime[k]+=stime[k];										//PERFORMANCE
	texnd[k]+=sexnd[k];										//PERFORMANCE
	tscor[k]+=sscor[k];										//PERFORMANCE
	
	n_edge=0;
	fprintf(fresult,"Top-%d Answer: %d (ms)\n",k,res_time);
	fprintf(fresult,"Root: %s\n",r->rowid);
	DETECTOR_print(r,s,0);
	fprintf(fresult,"Result Size: %d\n",n_edge+1);
}

void DETECTOR()
{
	int pi;
	State r;
	Node *rp,*pp;
	char rs,ps,ss;
	Edge *e;

	int res_time;
	//int temp_s,temp_t;
	SCORETYPE temp;

	DETECTOR_init();

	memset(stime,0,sizeof(stime));				//PERFORMANCE
	memset(sexnd,0,sizeof(sexnd));				//PERFORMANCE
	memset(sscor,0,sizeof(sscor));				//PERFORMANCE
	k=0;

	res_time=clock();
	while (!queue.isEmpty())
	{
		r=queue.pop();
		rp=r.p;
		rs=r.s;

		if (rs==(nn)-1)
		{
			ad[k]=0;
			DETECTOR_gettree(rp,rs);
			if (DETECTOR_existtree())
				continue;

			DETECTOR_output(rp,rs,k++,clock()-res_time);
			if (k==TOPK)
				break;
			continue;
		}

		for (e=r.p->edge; e; e=e->next)
		{
			pp=e->node;
			
			/*
			temp_s=clock();
			if (pp->mt==0)
				DETECTOR_newnode(pp);
			temp_t=clock();
			res_time+=(temp_t-temp_s);
			*/

			if (pp->vis==0)						//PERFORMANCE
			{									//PERFORMANCE
				pp->vis=1;						//PERFORMANCE
				sexnd[k]++;						//PERFORMANCE
			}									//PERFORMANCE

			temp=rp->mt[rs]+e->weight;
			if (temp<pp->mt[rs])
			{
				pp->mt[rs]=temp;
				pp->suf[rs]=rp;
				pp->pat[rs]=0;
				if (pp->ind[rs]==-1)
					queue.push(State(pp,rs));
				else
					queue.update(pp->ind[rs]);
			}
		}

		for (pi=0; pi<nNS[rs]; pi++)
		{
			ps=NS[rs][pi];
			if (rp->mt[ps]!=NA)
			{
				ss=(rs|ps);
				temp=rp->mt[rs]+rp->mt[ps];
				if (temp<rp->mt[ss])
				{
					rp->mt[ss]=temp;
					rp->suf[ss]=0;
					rp->pat[ss]=rs;
					if (rp->ind[ss]==-1)
						queue.push(State(rp,ss));
					else
						queue.update(rp->ind[ss]);
				}
			}
		}
	}
	fprintf(fresult,"---ANSWER ENDS---\n\n\n");
					
	DETECTOR_clear();
}

int run()
{
	int i;

	printf("Reading Database ...\n");
	readIn();

	memset(ttime,0,sizeof(ttime));					//PERFORMANCE
	memset(texnd,0,sizeof(texnd));					//PERFORMANCE
	memset(tscor,0,sizeof(tscor));					//PERFORMANCE
	testdata=0;										//PERFORMANCE

	printf("Getting Next Query ...\n");
	while( getKey() )
	{
		testdata++;									//PERFORMANCE
		fprintf(ftime,"%d\n",testdata);				//PERFORMANCE
		printf("Searching ...\n");
		DETECTOR();
		fprintf(ftime,"\n");						//PERFORMANCE
		printf("Getting Next Query ...\n");
	}

	//PERFORMANCE
	fprintf(ftime,"=================\n");													
	//PERFORMANCE
	for (i=0; i<TOPK; i++)
		fprintf(ftime,"%0.2lf %0.2lf %0.2lf\n",(double)ttime[i]/testdata,(double)texnd[i]/testdata,(double)tscor[i]/testdata);
	//PERFORMANCE

	printf("END\n");
	closeIt();
	return 0;
}

int main()
{
	int i,numrun;

	strcpy(_frun,"run.txt");
	frun=fopen(_frun,"r");
	
	fscanf(frun,"%d",&numrun);
	for (i=0; i<numrun; i++)
	{
		printf("%d of %d\n",i,numrun);
		fscanf(frun,"%s %s %s %s %s",_fgraph,_fstring,_fquery,_fresult,_ftime);
		run();
	}
	fclose(frun);
	return 0;
}