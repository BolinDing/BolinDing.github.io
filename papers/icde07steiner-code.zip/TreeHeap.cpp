#include "struct.h"
#include "TreeHeap.h"
#include "ResultTree.h"
#include <string.h>

TreeHeap::TreeHeap()
{
	tot = 1;
	memset( tab, 0, sizeof( tab ) );
}

TreeHeap::~TreeHeap()
{
	for( int i = 0; i < NHASH; ++i )
	{
		ResultTree *now = tab[i];
		while( now )
		{
			ResultTree *pre = now;
			now = now->next;
			delete pre;
		}
	}
}

void TreeHeap::up( int p )
{
	ResultTree *tmp = heap[p];
	for( int i = p >> 1; i >= 1; i >>= 1 )
	{
		if( heap[i]->cost <= tmp->cost )
			break;
		heap[p] = heap[i];
		heap[p]->index = p;
		p = i;
	}
	heap[p] = tmp;
	heap[p]->index = p;
}

void TreeHeap::down( int p )
{
	ResultTree *tmp = heap[p];
    for( int i = p << 1; i < tot; i <<= 1 )
    {
      if( i + 1 < tot && heap[i]->cost > heap[i + 1]->cost )
        ++i;
	  if( heap[i]->cost >= tmp->cost )
		  break;
	  heap[p] = heap[i];
	  heap[p]->index = p;
      p = i;
    }
	heap[p] = tmp;
	heap[p]->index = p;
}

ResultTree *TreeHeap::removeMin()
{
	if( tot == 1 )
		return NULL;
	ResultTree *tmp = heap[1];
	heap[1] = heap[--tot];
	heap[1]->index = 1;
	down( 1 );
	return tmp;
}

void TreeHeap::add( ResultTree *now )
{
	ResultTree *r = find( now );
	if( r )
	{
		if( now->cost < r->cost )
		{
			r->cost = now->cost;
			up( r->index );
		}
		delete now;
		return;
	}
	int h = now->hash();
	now->next = tab[h];
	tab[h] = now;
	heap[tot] = now;
	up( tot++ );
}

ResultTree *TreeHeap::find( ResultTree *now )
{
	int h = now->hash();
	for( ResultTree *r = tab[h]; r; r = r->next )
		if( r->equals( now ) )
			return r;
	return NULL;
}

int TreeHeap::size()
{
	return tot - 1;
}