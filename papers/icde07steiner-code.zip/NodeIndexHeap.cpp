#include "struct.h"
#include "NodeIndexHeap.h"
#include <stdio.h>
#include <string.h>

extern int n;

NodeIndexHeap::NodeIndexHeap()
{
	tot = 1;
	memset( tab, 0, sizeof( tab ) );
}

void NodeIndexHeap::up( int p )
{
	IndexHeapNode *tmp = heap[p];
	for( int i = p >> 1; i >= 1; i >>= 1 )
	{
		if( heap[i]->node->act >= tmp->node->act )
			break;
		heap[p] = heap[i];
		heap[p]->index = p;
		p = i;
	}
	heap[p] = tmp;
	heap[p]->index = p;
}

void NodeIndexHeap::down( int p )
{
	IndexHeapNode *tmp = heap[p];
    for( int i = p << 1; i < tot; i <<= 1 )
    {
      if( i + 1 < tot && heap[i]->node->act < heap[i + 1]->node->act )
        ++i;
	  if( heap[i]->node->act <= tmp->node->act )
		  break;
	  heap[p] = heap[i];
	  heap[p]->index = p;
      p = i;
    }
	heap[p] = tmp;
	heap[p]->index = p;
}

void NodeIndexHeap::add( Node *nod )
{
	IndexHeapNode *now = new IndexHeapNode();
	now->node = nod;
	heap[tot] = now;
	int h = nod->p % NHASH;
	now->next = tab[h];
	tab[h] = now;
	up( tot++ );
}

bool NodeIndexHeap::isEmpty()
{
	return tot == 1;
}

Node *NodeIndexHeap::getMin()
{
	if( tot == 1 )
		return NULL;
	return heap[1]->node;
}

Node *NodeIndexHeap::removeMin()
{
	IndexHeapNode * now = heap[1];
	Node *tmp = now->node;
	heap[1] = heap[--tot];
	heap[1]->index = 1;
	down( 1 );
	int h = tmp->p % NHASH;
	if( tab[h]->node->p == tmp->p )
		tab[h] = tab[h]->next;
	else
	{
		IndexHeapNode *pre = tab[h], *now = tab[h]->next;
		while( now->node->p != tmp->p )
		{
			pre = now;
			now = now->next;
		}
		pre->next = now->next;
	}
	delete now;
	return tmp;
}

void NodeIndexHeap::update( Node *nod )
{
	IndexHeapNode *now = find( nod );
	up( now->index );
}

IndexHeapNode* NodeIndexHeap::find( Node *nod )
{
	int h = nod->p % NHASH;
	for( IndexHeapNode* now = tab[h]; now; now = now->next )
		if( now->node->p == nod->p )
			return now;
	return NULL;
}

NodeIndexHeap::~NodeIndexHeap()
{
	for( int i = 0; i < NHASH; ++i )
	{
		IndexHeapNode *now = tab[i];
		while( now )
		{
			IndexHeapNode *pre = now;
			now = now->next;
			delete pre;
		}
	}
}