#pragma once
#include "DataCubeHelper.h"
class CDataCube
{
	friend CDataCubeHelper;

private:

protected:

public:
	int m_cCubeDim;
	int* m_rgcCubeCard;
	int m_cCubeSize;
	double* m_rgrCubeData;

	CDataCube(void);
	~CDataCube(void);

	int BaseCuboid() { return (1 << m_cCubeDim) - 1; };
	int CubeDim() { return m_cCubeDim; };
	int CubeCard(int i) { return m_rgcCubeCard[i]; };
	int CubeSize() { return m_cCubeSize; };
	int CubeNumberOfRows() { int ret = 1; for (int i = 0; i < CubeDim(); i++) ret *= CubeCard(i); return ret; };
	
	int CuboidDim(int cuboid);
	int CuboidSize(int cuboid);
	int CuboidFreedom(int cuboid);
	void CuboidCellsEnum(int d, int *cell, int cuboid, int &n, int *ind);
	int *CuboidCells(int cuboid, int &n, int *ind);
	
	double NormL1All();
	double NormL1Base();
	double NormL1CuboidEnum(int d, int *cell, int cuboid);
	double NormL1Cuboid(int cuboid);
	double NormL2All();
	double NormL2Base();
	double NormL2CuboidEnum(int d, int *cell, int cuboid);
	double NormL2Cuboid(int cuboid);

	int IndexCell(int *cell);

	void ReadTableStructure(char *filename);
	void SetToZero();
	void EraseData();
};

