#include "DataCubeHelper.h"
#include "Header.h"

CDataCubeHelper::CDataCubeHelper(void)
{
}


CDataCubeHelper::~CDataCubeHelper(void)
{
}


int CDataCubeHelper::StringToInt(char* tmp)
{
	int base = 1;
	int ret = 0;
	for (unsigned int d = 0; d < strlen(tmp); d++)
	{
		if (tmp[d] != '0' && tmp[d] != '1')
			break;
		ret += base*(tmp[d]=='1');
		base = base*2;
	}
	return ret;
}


double CDataCubeHelper::NoiseLaplace(double b, double eps)
{
	int temp = rand();
	while (temp == 0 || temp == RAND_MAX)
		temp = rand();
	double U = ((double)(temp)) / ((double)(RAND_MAX)) - (double)0.5;
	double sign;
	if (U < 0)
		sign = -1.0;
	else
		sign = 1.0;
	return (double)(-1.0 * b / eps) * sign * log(1 - 2 * fabs(U));
}
