#include "DataCube.h"
#include "Header.h"

CDataCube::CDataCube(void)
{
	this->m_cCubeDim = 0;
	this->m_cCubeSize = 0;
	this->m_rgcCubeCard = 0;
	this->m_rgrCubeData = 0;
}


CDataCube::~CDataCube(void)
{
	if (this->m_rgcCubeCard)
		delete this->m_rgcCubeCard;
	if (this->m_rgrCubeData)
		delete this->m_rgrCubeData;
}


void CDataCube::EraseData()
{
	if (this->m_rgcCubeCard)
		delete this->m_rgcCubeCard;
	if (this->m_rgrCubeData)
		delete this->m_rgrCubeData;
}


void CDataCube::SetToZero()
{
	memset(m_rgrCubeData, 0, m_cCubeSize * sizeof(double));
}


int CDataCube::CuboidDim(int cuboid)
{
	int ret = 0;
	for (int i = 0; i < CubeDim(); i++)
		if (cuboid & (1 << i))
			ret++;
	return ret;
}


int CDataCube::CuboidSize(int cuboid)
{
	int ret = 1;
	for (int i = 0; i < CubeDim(); i++)
		if (cuboid & (1 << i))
			ret *= CubeCard(i);
	return ret;
}


int CDataCube::CuboidFreedom(int cuboid)
{
	int ret = 1;
	for (int i = 0; i < CubeDim(); i++)
		if (!(cuboid & (1 << i)))
			ret *= CubeCard(i);
	return ret;
}


void CDataCube::CuboidCellsEnum(int d, int *cell, int cuboid, int &n, int *ind)
{
	if (d == m_cCubeDim)
		ind[n++] = IndexCell(cell);
	else
	{
		if (cuboid & (1 << d))
			for (int i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				CuboidCellsEnum(d + 1, cell, cuboid, n, ind);
			}
		else
		{
			cell[d] = 0;
			CuboidCellsEnum(d + 1, cell, cuboid, n, ind);
		}
	}
}


int *CDataCube::CuboidCells(int cuboid, int &n, int *ind)
{
	int *cell = new int[m_cCubeDim];
	n = 0;
	CuboidCellsEnum(0, cell, cuboid, n, ind);
	delete cell;
	return ind;
}


void CDataCube::ReadTableStructure(char *filename)
{
	ifstream fin;
	fin.open(filename, ios::in);
	if (fin.fail())
	{
		cout << "Table Structure file " << filename << " does not exist" << endl;
		exit(1);
	}
	fin >> m_cCubeDim;
	if (m_rgcCubeCard)
		delete m_rgcCubeCard;
	m_rgcCubeCard = new int[m_cCubeDim];
	m_cCubeSize = 1;
	for (int d = 0; d < m_cCubeDim; d++)
	{
		fin >> m_rgcCubeCard[d];
		m_cCubeSize *= (m_rgcCubeCard[d]+1);
	}
	if (m_rgrCubeData)
		delete m_rgrCubeData;
	m_rgrCubeData = new double[m_cCubeSize];
	memset(m_rgrCubeData, 0, m_cCubeSize * sizeof(double));
}


int CDataCube::IndexCell(int* cell)
{
	int ret=0;
	int bas=1;
	for (int i = 0; i < m_cCubeDim; i++)
	{
		ret += cell[i] * bas;
		bas *= m_rgcCubeCard[i] + 1;
	}
	return ret;
}


double CDataCube::NormL1All()
{
	double ret = 0;
	for (int i = 0; i < m_cCubeSize; i++)
		ret += fabs(m_rgrCubeData[i]);
	return ret;
}


double CDataCube::NormL1Base()
{
	return NormL1Cuboid(BaseCuboid());
}


double CDataCube::NormL1CuboidEnum(int d, int* cell, int cuboid)
{
	if (d == m_cCubeDim)
		return fabs(m_rgrCubeData[IndexCell(cell)]);
	else
	{
		double ret = 0;
		if (cuboid & (1 << d))
			for (int i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				ret += NormL1CuboidEnum(d+1, cell, cuboid);
			}
		else
		{
			cell[d] = 0;
			ret += NormL1CuboidEnum(d+1, cell, cuboid);
		}
		return ret;
	}
}


double CDataCube::NormL1Cuboid(int cuboid)
{
	int* cell = new int[m_cCubeDim];
	return NormL1CuboidEnum(0, cell, cuboid);
}


double CDataCube::NormL2All()
{
	double ret = 0;
	for (int i = 0; i < m_cCubeSize; i++)
		ret += m_rgrCubeData[i] * m_rgrCubeData[i];
	return ret;
}


double CDataCube::NormL2Base()
{
	return NormL2Cuboid(BaseCuboid());
}


double CDataCube::NormL2CuboidEnum(int d, int* cell, int cuboid)
{
	if (d == m_cCubeDim)
		return m_rgrCubeData[IndexCell(cell)] * m_rgrCubeData[IndexCell(cell)];
	else
	{
		double ret = 0;
		if (cuboid & (1 << d))
			for (int i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				ret += NormL2CuboidEnum(d+1, cell, cuboid);
			}
		else
		{
			cell[d] = 0;
			ret += NormL2CuboidEnum(d+1, cell, cuboid);
		}
		return ret;
	}
}


double CDataCube::NormL2Cuboid(int cuboid)
{
	int* cell = new int[m_cCubeDim];
	return NormL2CuboidEnum(0, cell, cuboid);
}
