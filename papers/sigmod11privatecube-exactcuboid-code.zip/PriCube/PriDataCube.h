#pragma once
#include "DataCube.h"
class CPriDataCube :
	public CDataCube
{
	friend CDataCubeHelper;

private:

protected:

public:
	int m_cLpreSize;
	int* m_rgsLpre;
	double* m_rgrLpreNoise;

	double m_rEps;

	CPriDataCube(void);
	~CPriDataCube(void);
	void EraseData();

	void SetEps(double eps) { m_rEps = eps; };
	double GetEps() { return m_rEps; };

	void ReadLpre(char *filename);
	void ReadLpreNoise(char *filename);

	bool InLpre(int cuboid);

	void InjectNoiseAllDfs(int d, int *cell);
	void InjectNoiseAll();
	
	void InjectNoiseBaseDfs(int d, int *cell);	
	void InjectNoiseBase(double eps) { SetEps(eps); InjectNoiseBase(); };
	void InjectNoiseBase();

	void InjectNoiseOptDfs(int d, int *cell, int cuboid, double noise);
	void InjectNoiseOpt();

	void CheckConsistencyEnumBase(int d, int *cell, int cuboid, double &sum);
	bool CheckConsistencyEnumCell(int d, int *cell, int cuboid);
	bool CheckConsistency(int cuboid);
	bool CheckConsistency(char *cuboid);

	void EnforceConsistencyOneCuboidCorrBase(int d, int *cell, int cuboid, double cor);
	void EnforceConsistencyOneCuboidEnumBase(int d, int *cell, int cuboid, double &sum);
	void EnforceConsistencyOneCuboidEnumCell(int d, int *cell, int cuboid);
	void EnforceConsistencyOneCuboid(int cuboid);
	void EnforceConsistencyOneCuboid(char *cuboid);


	void EnforceConsistencyTwoCuboidsObs(int d, int *cell, int *cell1, int *cell2, int cuboid1, int cuboid2, double *obs);
	void EnforceConsistencyTwoCuboidsRef(int d, int *cell, int *cell1, int *cell2, int cuboid1, int cuboid2, double *lag);
	void EnforceConsistencyTwoCuboids(int cuboid1, int cuboid2);
	void EnforceConsistencyTwoCuboids(char *cuboid1, char *cuboid2);
};

