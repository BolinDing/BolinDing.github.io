#pragma once
class CDataCubeHelper
{
public:
	CDataCubeHelper(void);
	~CDataCubeHelper(void);
	
	static int StringToInt(char *tmp);
	static double NoiseLaplace(double b, double eps);
};