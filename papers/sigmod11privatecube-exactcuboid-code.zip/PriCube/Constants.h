#define _CRT_SECURE_NO_WARNINGS

#define MAXD 12
#define MAXL 4096
#define NA -1
#define PAR_IN 1

#define uint64 unsigned __int64
#define int64 __int64

#define CUBE_STRUCTURE double*
#define CUBE_STRUCTURE_IND int
#define CUBE_STRUCTURE_NODE double