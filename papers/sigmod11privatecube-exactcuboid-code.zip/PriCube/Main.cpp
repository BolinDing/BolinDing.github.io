#include "Header.h"
#include "Constants.h"
#include "DataCube.h"
#include "PriDataCube.h"

void test0()
{
	CPriDataCube* cube = new CPriDataCube;
	cube->ReadTableStructure("Tables.txt");
	cube->InjectNoiseBase(1);
	printf("%0.6lf\n", cube->NormL1Base());
	cube->EnforceConsistencyTwoCuboids("11110000", "00001111");
	printf("%0.6lf\n", cube->NormL1Base());
	if (cube->CheckConsistency("10") && cube->CheckConsistency("01"))
		printf("Consistent!\n");
	else
		printf("Inconsistent!\n");
	delete cube;
}

void test1()
{
	FILE *fin = fopen("output.txt", "w");
	CPriDataCube* cube = new CPriDataCube;

	cube->ReadTableStructure("Tables.txt");

	char *cuboid1[7] = {"10000000", "11000000", "11100000", "11110000", "11111000", "11111100", "11111110"};
	char *cuboid2[7] = {"01111111", "00111111", "00011111", "00001111", "00000111", "00000011", "00000001"};
	double eps1[7] = {1.0/2, 1.0/2, 1.0/2,  1.0/2,  1.0/2,  1.0/2, 1.0/2};
	double eps2[7] = {1.0/4, 1.0/8, 1.0/16, 1.0/32, 1.0/16, 1.0/8, 1.0/4};

	for (int i = 0; i < 7; i++)
	{
		double err1 = 0;
		double err2 = 0;
		for (int j = 0; j < 10; j++)
		{
			cube->SetToZero();
			cube->InjectNoiseBase(eps1[i]);
			err1 += cube->NormL1Base() / cube->CubeNumberOfRows();
			cube->EnforceConsistencyOneCuboid(cuboid1[i]);
			err2 += cube->NormL1Base() / cube->CubeNumberOfRows();			
		}
		fprintf(fin, "%0.6lf\t%0.6lf\n", err1/10, err2/10);
		printf("%0.6lf\t%0.6lf\n", err1/10, err2/10);
	}
	fprintf(fin, "\n");

	for (int i = 0; i < 7; i++)
	{
		double err1 = 0;
		double err2 = 0;
		for (int j = 0; j < 10; j++)
		{
			cube->SetToZero();
			cube->InjectNoiseBase(eps2[i]);
			err1 += cube->NormL1Base() / cube->CubeNumberOfRows();
			cube->EnforceConsistencyTwoCuboids(cuboid1[i], cuboid2[i]);
			err2 += cube->NormL1Base() / cube->CubeNumberOfRows();			
		}
		fprintf(fin, "%0.6lf\t%0.6lf\n", err1/10, err2/10);
		printf("%0.6lf\t%0.6lf\n", err1/10, err2/10);
	}
	fprintf(fin, "\n");

	delete cube;
	fclose(fin);
}

int main()
{
	test1();
	return 0;
}