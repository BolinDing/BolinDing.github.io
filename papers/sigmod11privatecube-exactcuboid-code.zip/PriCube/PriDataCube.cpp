#include "PriDataCube.h"
#include "DataCubeHelper.h"
#include "Header.h"

CPriDataCube::CPriDataCube(void)
{
	this->m_cLpreSize = 0;
	this->m_rEps = 1;
	this->m_rgsLpre = 0;
	this->m_rgrLpreNoise = 0;
}


CPriDataCube::~CPriDataCube(void)
{
	if (this->m_rgsLpre)
		delete this->m_rgsLpre;
	if (this->m_rgrLpreNoise)
		delete this->m_rgrLpreNoise;
}


void CPriDataCube::EraseData()
{
	if (this->m_rgsLpre)
		delete this->m_rgsLpre;
	if (this->m_rgrLpreNoise)
		delete this->m_rgrLpreNoise;
	CDataCube::EraseData();
}


void CPriDataCube::ReadLpre(char *filename)
{
	ifstream fin;
	fin.open(filename, ios::in);
	if (fin.fail())
	{
		cout << "Lpre file " << filename << " does not exist" << endl;
		exit(1);
	}
	char* tmp = new char[CubeDim() + 10];
	fin >> m_cLpreSize;
	m_rgsLpre = new int[m_cLpreSize];
	m_rgrLpreNoise = new double[m_cLpreSize];
	for (int i = 0; i < m_cLpreSize; i++)
	{
		fin >> tmp;
		m_rgsLpre[i] = CDataCubeHelper::StringToInt(tmp);
		m_rgrLpreNoise[i]=(double)m_cLpreSize;
	}
	fin.close();
}


void CPriDataCube::ReadLpreNoise(char *filename)
{
	ifstream fin;
	fin.open(filename, ios::in);
	if (fin.fail())
	{
		cout << "Lpre file " << filename << " does not exist" << endl;
		exit(1);
	}
	char* tmp = new char[CubeDim() + 10];
	fin >> m_cLpreSize;
	m_rgsLpre = new int[m_cLpreSize];
	m_rgrLpreNoise = new double[m_cLpreSize];
	for (int i = 0; i < m_cLpreSize; i++)
	{
		fin >> tmp;
		m_rgsLpre[i] = CDataCubeHelper::StringToInt(tmp);
		fin >> m_rgrLpreNoise[i];
	}
	fin.close();
}


bool CPriDataCube::InLpre(int cuboid)
{
	for (int i = 0; i < m_cLpreSize; i++)
		if (m_rgsLpre[i] == cuboid)
			return true;
	return false;
}


void CPriDataCube::InjectNoiseAllDfs(int d, int* cell)
{
	if (d == m_cCubeDim)
		m_rgrCubeData[IndexCell(cell)] = CDataCubeHelper::NoiseLaplace(m_cLpreSize, GetEps());
	else
		for (int i = 0; i <= m_rgcCubeCard[d]; i++)
		{
			cell[d] = i;
			InjectNoiseAllDfs(d+1, cell);
		}
}


void CPriDataCube::InjectNoiseAll()
{
	int* cell = new int[m_cCubeDim];
	srand ( (unsigned int)time(NULL) );
	InjectNoiseAllDfs(0, cell);
	delete cell;
}


void CPriDataCube::InjectNoiseBaseDfs(int d, int* cell)
{
	if (d == m_cCubeDim)
		m_rgrCubeData[IndexCell(cell)] = CDataCubeHelper::NoiseLaplace(1, GetEps());
	else
		for (int i = 1; i <= m_rgcCubeCard[d]; i++)
		{
			cell[d] = i;
			InjectNoiseBaseDfs(d+1, cell);
		}
}


void CPriDataCube::InjectNoiseBase()
{
	int* cell = new int[m_cCubeDim];
	srand ( (unsigned int)time(NULL) );
	InjectNoiseBaseDfs(0, cell);
	delete cell;
}


void CPriDataCube::InjectNoiseOptDfs(int d, int* cell, int cuboid, double noise)
{
	if (d == m_cCubeDim)
		m_rgrCubeData[IndexCell(cell)] = CDataCubeHelper::NoiseLaplace(noise, GetEps());
	else
	{
		if (cuboid & ( 1<<d ))
			for (int i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				InjectNoiseOptDfs(d+1, cell, cuboid, noise);
			}
		else
		{
			cell[d] = 0;
			InjectNoiseOptDfs(d+1, cell, cuboid, noise);
		}
	}
}

void CPriDataCube::InjectNoiseOpt()
{
	int* cell = new int[m_cCubeDim];
	srand ( (unsigned int)time(NULL) );
	for (int i = 0; i < m_cLpreSize; i++)
		InjectNoiseOptDfs(0, cell, m_rgsLpre[i], m_rgrLpreNoise[i]);
	delete cell;
}


void CPriDataCube::EnforceConsistencyOneCuboidCorrBase(int d, int* cell, int cuboid, double cor)
{
	if (d == m_cCubeDim)
		m_rgrCubeData[IndexCell(cell)] -= cor;
	else
	{
		if (!(cuboid & (1 << d)))
			for (int  i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				EnforceConsistencyOneCuboidCorrBase(d + 1, cell, cuboid, cor);
			}
		else
			EnforceConsistencyOneCuboidCorrBase(d + 1, cell, cuboid, cor);
	}
}


void CPriDataCube::EnforceConsistencyOneCuboidEnumBase(int d, int* cell, int cuboid, double &sum)
{
	if (d == m_cCubeDim)
		sum += m_rgrCubeData[IndexCell(cell)];
	else
	{
		if (!(cuboid & (1 << d)))
			for (int  i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				EnforceConsistencyOneCuboidEnumBase(d + 1, cell, cuboid, sum);
			}
		else
			EnforceConsistencyOneCuboidEnumBase(d + 1, cell, cuboid, sum);
	}
}


void CPriDataCube::EnforceConsistencyOneCuboidEnumCell(int d, int* cell, int cuboid)
{
	if (d == m_cCubeDim)
	{
		double sum = 0;
		EnforceConsistencyOneCuboidEnumBase(0, cell, cuboid, sum);
		double cor = sum / CuboidFreedom(cuboid);
		EnforceConsistencyOneCuboidCorrBase(0, cell, cuboid, cor);
	}
	else
	{
		if (cuboid & (1 << d))
			for (int  i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				EnforceConsistencyOneCuboidEnumCell(d + 1, cell, cuboid);
			}
		else
		{
			cell[d] = 0;
			EnforceConsistencyOneCuboidEnumCell(d + 1, cell, cuboid);
		}
	}
}


void CPriDataCube::EnforceConsistencyOneCuboid(int cuboid)
{
	int* cell = new int[m_cCubeDim];
	EnforceConsistencyOneCuboidEnumCell(0, cell, cuboid);
	delete cell;
}


void CPriDataCube::EnforceConsistencyOneCuboid(char* cuboid)
{
	EnforceConsistencyOneCuboid(CDataCubeHelper::StringToInt(cuboid));
}


void CPriDataCube::EnforceConsistencyTwoCuboidsObs(int d, int* cell, int* cell1, int* cell2, int cuboid1, int cuboid2, double* obs)
{
	if (d == m_cCubeDim)
	{
		int ind = IndexCell(cell);
		int ind1 = IndexCell(cell1);
		int ind2 = IndexCell(cell2);
		obs[ind1] += m_rgrCubeData[ind];
		obs[ind2] += m_rgrCubeData[ind];
	}
	else
	{
		for (int  i = 1; i <= m_rgcCubeCard[d]; i++)
		{
			cell[d] = i;
			if (cuboid1 & (1 << d))
				cell1[d] = i;
			else
				cell1[d] = 0;
			if (cuboid2 & (1 << d))
				cell2[d] = i;
			else
				cell2[d] = 0;
			EnforceConsistencyTwoCuboidsObs(d + 1, cell, cell1, cell2, cuboid1, cuboid2, obs);
		}
	}
}


void CPriDataCube::EnforceConsistencyTwoCuboidsRef(int d, int *cell, int *cell1, int *cell2, int cuboid1, int cuboid2, double *lag)
{
	if (d == m_cCubeDim)
	{
		int ind = IndexCell(cell);
		int ind1 = IndexCell(cell1);
		int ind2 = IndexCell(cell2);
		m_rgrCubeData[ind] -= lag[ind1] + lag[ind2];
	}
	else
	{
		for (int  i = 1; i <= m_rgcCubeCard[d]; i++)
		{
			cell[d] = i;
			if (cuboid1 & (1 << d))
				cell1[d] = i;
			else
				cell1[d] = 0;
			if (cuboid2 & (1 << d))
				cell2[d] = i;
			else
				cell2[d] = 0;
			EnforceConsistencyTwoCuboidsRef(d + 1, cell, cell1, cell2, cuboid1, cuboid2, lag);
		}
	}
}


void CPriDataCube::EnforceConsistencyTwoCuboids(int cuboid1, int cuboid2)
{
	double *obs = new double[m_cCubeSize];
	double *lag = new double[m_cCubeSize];
	memset(obs, 0, m_cCubeSize * sizeof(double));
	memset(lag, 0, m_cCubeSize * sizeof(double));
	int *cell = new int[m_cCubeDim];
	int *cell1 = new int[m_cCubeDim];
	int *cell2 = new int[m_cCubeDim];
	int *ind1 = new int[CuboidSize(cuboid1)];
	int *ind2 = new int[CuboidSize(cuboid2)];
	int n1 = 0;
	int n2 = 0;
	ind1 = CuboidCells(cuboid1, n1, ind1);
	ind2 = CuboidCells(cuboid2, n2, ind2);
	double sz1 = CuboidFreedom(cuboid1);
	double sz2 = CuboidFreedom(cuboid2);
	double f = CuboidFreedom(cuboid1 | cuboid2);

	EnforceConsistencyTwoCuboidsObs(0, cell, cell1, cell2, cuboid1, cuboid2, obs);

	double sum1 = 0;
	for (int i = 0; i < n1; i++)
		sum1 += obs[ind1[i]];
	sum1 *= -f / sz1;
	for (int i = 0; i < n2; i++)
		obs[ind2[i]] += sum1;

	double dia = sz2 - f * f * n1 / sz1;
	double res = - f * f * n1 / sz1;

	double sum2 = 0;
	for (int i = 0; i < n2 - 1; i++)
		sum2 += obs[ind2[i]];
	double coe = dia + (n2 - 2) * res;
	double nos = sum2 / coe;

	for (int i = 0; i < n2 - 1; i++)
		lag[ind2[i]] = (obs[ind2[i]] - nos * res) / (dia - res);
	lag[ind2[n2 - 1]] = 0;
	for (int i = 0; i < n1; i++)
		lag[ind1[i]] = (obs[ind1[i]] - nos * f) / sz1;

	EnforceConsistencyTwoCuboidsRef(0, cell, cell1, cell2, cuboid1, cuboid2, lag);

	delete obs;
	delete cell;
	delete cell1;
	delete cell2;
	delete ind1;
	delete ind2;
}


void CPriDataCube::EnforceConsistencyTwoCuboids(char *cuboid1, char *cuboid2)
{
	EnforceConsistencyTwoCuboids(CDataCubeHelper::StringToInt(cuboid1), CDataCubeHelper::StringToInt(cuboid2));
}


void CPriDataCube::CheckConsistencyEnumBase(int d, int* cell, int cuboid, double &sum)
{
	if (d == m_cCubeDim)
		sum += m_rgrCubeData[IndexCell(cell)];
	else
	{
		if (!(cuboid & (1 << d)))
			for (int  i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				EnforceConsistencyOneCuboidEnumBase(d + 1, cell, cuboid, sum);
			}
		else
			EnforceConsistencyOneCuboidEnumBase(d + 1, cell, cuboid, sum);
	}
}


bool CPriDataCube::CheckConsistencyEnumCell(int d, int* cell, int cuboid)
{
	if (d == m_cCubeDim)
	{
		double sum = 0;
		CheckConsistencyEnumBase(0, cell, cuboid, sum);
		if (fabs(sum) < 0.0000001)
			return true;
		else
			return false;
	}
	else
	{
		if (cuboid & (1 << d))
			for (int  i = 1; i <= m_rgcCubeCard[d]; i++)
			{
				cell[d] = i;
				if (!CheckConsistencyEnumCell(d + 1, cell, cuboid))
					return false;
			}
		else
		{
			cell[d] = 0;
			if (!CheckConsistencyEnumCell(d + 1, cell, cuboid))
				return false;
		}
		return true;
	}
}


bool CPriDataCube::CheckConsistency(int cuboid)
{
	int* cell = new int[m_cCubeDim];
	return CheckConsistencyEnumCell(0, cell, cuboid);
}


bool CPriDataCube::CheckConsistency(char* cuboid)
{
	return CheckConsistency(CDataCubeHelper::StringToInt(cuboid));
}
