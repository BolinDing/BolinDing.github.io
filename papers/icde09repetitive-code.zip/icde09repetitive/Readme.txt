1. Binary Code

all.exe --- GSgrow
close.exe --- CloGSgrow

Some important parameters restricted in these two programs:
Maximum number of different events <= 10000
Maximum number of sequences <= 50000
Maximum total length of sequences <= 2000000

To run them, type "all/closed filename min_sup", like
all data_D5C20N10S20.txt 20
or
closed data_D5C20N10S20.txt 20

2. Source Code

Please send email to bding3@uiuc.edu if you are interesed in getting the source code of our algorithms

3. Performance Study Data

Experiment 1: data_D5C20N10S20.txt, data_Gazelle.txt, adn data_TCAS.txt

Experiment 2: data.5.50.txt, data.10.50.txt, data.15.50.txt, data.20.50.txt, data.25.50.txt

Experiment 3: data.10.20.txt, data.10.40.txt, data.10.60.txt, data.10.80.txt, data.10.100.txt

4. Case Study Data

Data: data_JBoss.txt

Dictonary: data_JBoss_dictionary.txt
(used to interpret the output of our program)

