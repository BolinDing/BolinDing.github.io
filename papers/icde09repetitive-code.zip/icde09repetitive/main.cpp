#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<iostream>
#include<string>
#include<sstream>
#include<vector>
#include<stack>
#include<queue>
#include<set>
#include<map>
#include<algorithm>

#define MIN(a,b) ((a)>(b)?(b):(a))
#define MAX(a,b) ((a)<(b)?(b):(a))


#define STYPE int		// variable type to record event
#define MAXE 10000		// maximum number of events
#define MAXN 50000		// maximum number of sequences
#define MAXL 2000000	// maximum total length
#define MAXS 1000		// maximum length of strings

#define SEP -1			// seperator - seperating 
#define NA -3
#define UNICHAR 300

#define INF INF32
#define uint64 unsigned __int64
#define int64 __int64
#define _1 ((uint64)1)

const int64 INF64=(_1<<63)-1;
const int INF32=(_1<<31)-1;

using namespace std;

struct pindex{
	int siz;
	int *pos;
};

int n,m,s[MAXN],l[MAXN],db[MAXL];	// input data: n = # of sequences; s[i], l[i] = start position / length of sequence i; m = total length of sequences; db = database

vector<int> pos[MAXE];				// index of event position: pos[i][j] = the jth position of event i
map<int,pindex*> pst[MAXN];			// index
int res[MAXL];						// reversed index of pos[][]
int ind[MAXL];						// index of sequence number of each position
int next[MAXL];						// index of event position: next[i] = the next position of event db[i] in this sequence (or =-1 if no one left)

int nid;							// number of different events
int et[MAXE];						// et[i] = the ith event
map<int,int> id;					// index of event ID

int minsup;							// minimum support
int tot;							// total number of pattern

//int pls,mis;

class pattern{
public:
	vector<int> *p;		// pattern
	vector<int> *s;		// start positions of instances
	vector<int> *t;		// end positions of instances
	pattern()
	{
		p=new vector<int>;
		s=new vector<int>;
		t=new vector<int>;
		//pls++;
		//printf("%d %d\n",pls,mis);

	}
	int size()
	{
		return (int)t->size();
	}
	~pattern()
	{
		delete p;
		delete s;
		delete t;
		//mis++;
	}
};

void show(pattern *pat)
{
	int i;
	
	for (i=0; i<(int)pat->p->size(); i++)
	{
		if (i==0)
			printf("(");
		printf("%d",et[pat->p->at(i)]);
		if (i<(int)pat->p->size()-1)
			printf(" ");
		else
			printf(")");
	}
	printf(" %d\n",pat->t->size());
}

int last_position(vector<int> p,int j)
{
	int bck=0,frt=(int)p.size()-1,mid;

	j--;
	while (frt-bck>1)
	{
		mid=(frt+bck)/2;
		if (j==p[mid])
			return j;
		else if (j<p[mid])
			frt=mid;
		else
			bck=mid;
	}
	if (j<p[bck])
		return -1;
	else if (j==p[bck])
		return j;
	else if (j<p[frt])
		return p[bck];
	else if (j==p[frt])
		return j;
	else
		return p[frt];
}

int next_position(pindex *pin,int x,int bck)
{
	int *p=pin->pos;
	int frt=pin->siz-1,mid;

	if (bck>frt)
		return -1;
	if (x<=p[bck])
		return p[bck];
	if (x>p[frt])
		return -1;
	while (frt-bck>1)
	{
		mid=(frt+bck)/2;
		if (x==p[mid])
			return x;
		else if (x<p[mid])
			frt=mid;
		else
			bck=mid;
	}
	if (x<=p[bck])
		return p[bck];
	else if (x<=p[frt])
		return p[frt];
	else
		return -1;
}


void expand1(pattern *pat)
{
	int i,j,k;
	pattern *npat;

	if (pat->size()<minsup)
	{
		delete pat;
		return;
	}

	//show(pat);
	for (i=0; i<nid; i++)
	{
		npat=new pattern;
		
		npat->p->assign(pat->p->begin(),pat->p->end());
		npat->p->push_back(i);
		k=0;
		for (j=0; j<(int)pos[i].size()&&k<(int)pat->size(); j++)
		{
			while (ind[pat->s->at(k)]<ind[pos[i][j]])
			{
				k++;
				if (k==pat->size())
					break;
			}
			if (k==pat->size())
				break;
			if (ind[pat->s->at(k)]==ind[pos[i][j]]&&pat->t->at(k)<pos[i][j])
			{
				npat->s->push_back(pat->s->at(k));
				npat->t->push_back(pos[i][j]);
				k++;
			}	
		}
		expand1(npat);
	}
	delete pat;
}

int check(pattern *pat)
{
	int i,j,k,l,x,cnt;
	int newitm,preind,nxtpos;
	vector<int> t,nt,npat,nnpat,itm;
	vector<int>::iterator itp;
	map<int,int> pp;
	map<int,int>::iterator itpp;
	map<int,pindex*>::iterator it;
	pindex *newpos;
	int nclosed=0,prune=0;

	t=(*pat->s);

	cnt=0;
	for (i=0; i<(int)t.size();)
	{
		k=ind[t[i]];
		cnt++;
		for (it=pst[k].begin(); it!=pst[k].end(); it++)
		{
			if (pp.find(it->first)!=pp.end())
				pp[it->first]++;
			else
				pp[it->first]=1;
		}
		for (j=i; j<(int)t.size()&&ind[t[j]]==k; j++);
		i=j;
	}
	for (itpp=pp.begin(); itpp!=pp.end(); itpp++)
		if (itpp->second==cnt)
			itm.push_back(itpp->first);


	for (x=0; x<(int)pat->p->size(); x++)
	{
		for (itp=itm.begin(); itp!=itm.end(); itp++)
		{
			newitm=(*itp);
			for (i=0; i<(int)t.size();)
			{
				k=ind[t[i]];
				newpos=pst[k][newitm];
				preind=0;
				for (j=i; j<(int)t.size()&&ind[t[j]]==k; j++)
				{
					if (x>0)
						nxtpos=next_position(newpos,t[j]+1,preind);
					else
						nxtpos=next_position(newpos,-1,preind);
					if (nxtpos==-1)
						break;
					preind=res[nxtpos]+1;
					npat.push_back(nxtpos);
				}
				if (nxtpos==-1)
					break;
				for (j=i; j<(int)t.size()&&ind[t[j]]==k; j++);
				i=j;
			}
			if (i<(int)t.size())
			{
				npat.clear();
				continue;
			}
			if (newitm==pat->p->at(x))
			{
				nt=npat;
				npat.clear();
				continue;
			}
			for (l=x; l<(int)pat->p->size(); l++)
			{
				nnpat.clear();
				//for (i=0; i<(int)npat.size(); i++)
				for (i=0; i<(int)npat.size();)
				{
					k=ind[npat[i]];
					newpos=pst[k][pat->p->at(l)];
					preind=0;
					for (j=i; j<(int)npat.size()&&ind[npat[j]]==k; j++)
					{
						nxtpos=next_position(newpos,npat[j]+1,preind);
						if (nxtpos==-1)
							break;
						preind=res[nxtpos]+1;
						nnpat.push_back(nxtpos);
					}
					if (nxtpos==-1)
						break;
					for (j=i; j<(int)npat.size()&&ind[npat[j]]==k; j++);
					i=j;
				}
				if (i<(int)npat.size())
					break;
				npat=nnpat;
			}
			if (l==(int)pat->p->size())
			{
				nclosed=1;
				for (i=0; i<(int)npat.size(); i++)
					if (npat[i]>pat->t->at(i))
						break;
				if (i==(int)npat.size())
				{
					prune=1;
					return 2;
				}
			}
			npat.clear();
		}
		t=nt;
	}
	return nclosed;
}

void expand2(pattern *pat)
{
	int i,j,k;
	map<int,pattern*>  npat;
	map<int,pattern*>::iterator itpat;
	map<int,pindex* >::iterator it;
	int newitm,preind,nxtpos;
	pindex *newpos;

	if (pat->size()<minsup)
	{
		delete pat;
		return;
	}

	/*
	show(pat);
	*/

	tot++;
	for (i=0; i<(int)pat->size();)
	{
		k=ind[pat->s->at(i)];
		for (it=pst[k].begin(); it!=pst[k].end(); it++)
		{
			newitm=it->first;
			newpos=it->second;
			preind=0;
			for (j=i; j<(int)pat->size()&&ind[pat->s->at(j)]==k; j++)
			{
				nxtpos=next_position(newpos,pat->t->at(j)+1,preind);
				if (nxtpos==-1)
					break;
				preind=res[nxtpos]+1;
				if (npat.find(newitm)==npat.end())
				{
					npat[newitm]=new pattern;
					npat[newitm]->p->assign(pat->p->begin(),pat->p->end());
					npat[newitm]->p->push_back(newitm);
				}
				npat[newitm]->s->push_back(pat->s->at(j));
				npat[newitm]->t->push_back(nxtpos);
			}
		}
		for (j=i; j<(int)pat->size()&&ind[pat->s->at(j)]==k; j++);		
		i=j;
	}
	for (itpat=npat.begin(); itpat!=npat.end(); itpat++)
		expand2(itpat->second);
	delete pat;
}

void expand3(pattern *pat)
{
	int i,j,k,temp,flag;
	map<int,pattern*>  npat;
	map<int,pattern*>::iterator itpat;
	map<int,pindex* >::iterator it;
	int newitm,preind,nxtpos;
	pindex *newpos;

	if (pat->size()<minsup)
	{
		delete pat;
		return;
	}

	flag=0;
	temp=check(pat);
	if (temp==2)
	{
		delete pat;
		return;
	}
	else if (temp==0)
	{
		flag=1;
		tot++;
	}

	for (i=0; i<(int)pat->size();)
	{
		k=ind[pat->s->at(i)];
		for (it=pst[k].begin(); it!=pst[k].end(); it++)
		{
			newitm=it->first;
			newpos=it->second;
			preind=0;
			for (j=i; j<(int)pat->size()&&ind[pat->s->at(j)]==k; j++)
			{
				nxtpos=next_position(newpos,pat->t->at(j)+1,preind);
				if (nxtpos==-1)
					break;
				preind=res[nxtpos]+1;
				if (npat.find(newitm)==npat.end())
				{
					npat[newitm]=new pattern;
					npat[newitm]->p->assign(pat->p->begin(),pat->p->end());
					npat[newitm]->p->push_back(newitm);
				}
				npat[newitm]->s->push_back(pat->s->at(j));
				npat[newitm]->t->push_back(nxtpos);
			}
		}
		for (j=i; j<(int)pat->size()&&ind[pat->s->at(j)]==k; j++);		
		i=j;
	}
	temp=0;
	for (itpat=npat.begin(); itpat!=npat.end(); itpat++)
	{
		if (itpat->second->size()==pat->size())
			temp=1;
		expand3(itpat->second);
	}
	if (flag)
	{
		if (temp)
			tot--;
		/*
		else
			show(pat);
		*/
	}
	delete pat;
}

void search()
{
	int i;
	pattern *pat;

	for (i=0; i<nid; i++)
		if ((int)pos[i].size()>=minsup)
		{
			pat=new pattern;
			pat->p->push_back(i);
			pat->s->assign(pos[i].begin(),pos[i].end());
			pat->t->assign(pos[i].begin(),pos[i].end());
			//expand2(pat);
			expand3(pat);
		}
}

int getid(int x)
{
	if (id.find(x)==id.end())
	{
		et[nid]=x;
		id[x]=nid;
		nid++;
		return nid-1;
	}
	else
		return id[x];
}

int strnum(char *str)
{
	int i,ret;

	ret=0;
	if (str[0]!='-'&&(str[0]<'0'||str[0]>'9'))
		return -1;
	else
	{
		for (i=1; i<(int)strlen(str); i++)
			if (str[i]<'0'||str[i]>'9')
				break;
		if (i<(int)strlen(str))
			return -1;
	}
	if (str[0]=='-')
	{
		for (i=1; i<(int)strlen(str); i++)
			ret=ret*10-(str[i]-'0');
	}
	else if (str[0]>='0'&&str[0]<='9')
	{
		for (i=0; i<(int)strlen(str); i++)
			ret=ret*10+(str[i]-'0');
	}
	return ret;
}

void input(char filename[MAXS],double sup)
{
	int i,temp;
	char temps[MAXS];
	map<int,int> deg;
	map<int,int>::iterator ideg;
	FILE *fin=fopen(filename,"r");

	tot=0;
	n=1;
	m=0;
	nid=0;
	id.clear();
	memset(l,0,sizeof(int)*MAXN);
	memset(s,0,sizeof(int)*MAXN);
	memset(et,0,sizeof(int)*MAXE);
	memset(res,0,sizeof(int)*MAXL);
	memset(ind,0,sizeof(int)*MAXL);
	deg.clear();
	for (i=0; i<MAXE; i++)
		pos[i].clear();
	do
	{
		fscanf(fin,"%s",&temps);
		temp=strnum(temps);
		if (temp==-2)
		{
			n--;
			break;
		}
		else if (temp==-1)
		{
			for (ideg=deg.begin(); ideg!=deg.end(); ideg++)
			{
				pst[n-1][ideg->first]=new pindex;
				pst[n-1][ideg->first]->pos=new int[ideg->second];
				pst[n-1][ideg->first]->siz=0;
			}
			deg.clear();
			for (i=s[n-1]; i<s[n-1]+l[n-1]; i++)
			{
				pst[n-1][db[i]]->pos[pst[n-1][db[i]]->siz]=i;
				res[i]=pst[n-1][db[i]]->siz;
				pst[n-1][db[i]]->siz++;
			}
			db[m++]=SEP;
			s[n++]=m;
		}
		else
		{
			pos[getid(temp)].push_back(m);
			if (deg.find(getid(temp))==deg.end())
				deg[getid(temp)]=1;
			else
				deg[getid(temp)]++;
			ind[m]=n-1;
			db[m++]=getid(temp);
			l[n-1]++;
		}
	}
	while (1);
	minsup=(int)(sup);
	fclose(fin);
}

void build_next_index()
{
	int i,pt[MAXE];

	memset(pt,-1,sizeof(int)*MAXE);
	memset(next,-1,sizeof(int)*MAXL);
	for (i=0; i<m; i++)
	{
		if (db[i]==SEP)
			memset(pt,-1,sizeof(int)*MAXE);
		else
		{
			if (pt[db[i]]!=-1)
				next[pt[db[i]]]=i;
			pt[db[i]]=i;
		}
	}
}

int main(int argc,const char* argv[])
{
	int stime,ttime;
	char filename[MAXS];

	printf("Reading and indexing...\n");
	strcpy(filename,argv[1]);
	sscanf(argv[2],"%d",&minsup);
	input(filename,minsup);
	//input("test4.txt",3);
	/*
	build_next_index();
	*/
	stime=clock()/CLOCKS_PER_SEC;
	printf("Start searching...\n");
	search();
	ttime=clock()/CLOCKS_PER_SEC;
	printf("End with %d patterns in %d seconds\n",tot,ttime-stime);

	/*
	FILE *temp=fopen("bide_gaz.txt","r");
	int i=0,j;
	char jj[MAXS];

	while (1)
	{
		int ttt=fscanf(temp,"%s",jj);
		if (ttt==EOF)
			break;
		j=strnum(jj);
		i++;
		//printf("%d: %d %s \n",i,j,jj);
	}
	*/

	return 0;
}
