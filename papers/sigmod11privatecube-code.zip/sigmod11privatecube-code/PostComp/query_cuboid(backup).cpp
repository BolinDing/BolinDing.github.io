#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <time.h>
#include <map>
#include <math.h>

using namespace std;

#define MAXD 12
#define MAXL 4096

#define uint64 unsigned __int64
#define int64 __int64

const char* file_table = "../table.txt";
const char* file_opt = "../select.txt";
const char* file_table_dim = "../table_dim.txt";
const char* file_query = "../query.txt";
const char* file_publish_basecell = "../publish_basecell.txt";
const char* file_publish_cuboid = "../publish_cuboid.txt";
const char* file_publish_all = "../publish_all.txt";
  
struct CUBOID {
    int id;
    int num;
};

int card[MAXD]; // cardinality of each dimension
int n_dim; // number of dimensions
int n_base_cells; // number of base cells
int n_select_cuboids; //number of selected cuboids to materialize
int** base_cell; // base cells
int* select_cuboids;
map<string, double> data_cuboid, data_basecell, data_all;
double var_max;
double var_sum;
int var_n;
int* cell;

void readTableDim()
{
  ifstream fin;
  fin.open(file_table_dim, ios::in);
  if (fin.fail()) {
    cout << "File does not exist: " << file_table_dim << endl;
    exit(1);
  }
  fin >> n_dim;
  for (int d = 0; d < n_dim; d++) {
    fin >> card[d];
  }
  fin >> n_base_cells;
  fin.close();
}

int stringToInt(char* tmp)
{
  int base = 1;
  int res = 0;
  for (unsigned int d = 0; d < strlen(tmp); d++) {
    res += base*(tmp[d]=='1');
    base = base*2;
  }
  return res;
}

void readSelectedCuboids()
{
  ifstream fin;
  fin.open(file_opt, ios::in);
  if (fin.fail()) {
    cout << "File does not exist: " << file_opt << endl;
    exit(1);
  }
  fin >> n_select_cuboids;
  select_cuboids = new int[n_select_cuboids];
  char* tmp = new char[n_dim+10];
  for (int i = 0; i < n_select_cuboids; i++) {
    fin >> tmp;
    select_cuboids[i] = stringToInt(tmp);
  }
  fin.close();
}

void readData(const char* filename, map<string, double>& data)
{
  ifstream fin;
  fin.open(filename, ios::in);
  if (fin.fail()) {
    cout << "File does not exist: " << file_opt << endl;
    exit(1);
  }
  double noise;
  int temp=0;
  while (fin >> noise) {
    temp++;
    string str;
    for (int d = 0; d < n_dim; d++) {
      int v;
      fin >> v;
      str.append(1, char(65+v));
    }
    data[str] = noise;
  } 
  fin.close();
}

void readPublishData()
{
  readData(file_publish_cuboid, data_cuboid);
  readData(file_publish_basecell, data_basecell);
  readData(file_publish_all, data_all);
}

double DFS_cuboid(
    int query, 
    int cuboid, 
    int d, 
    int* cell, 
    map<string, double>& data) 
{
  if (d == n_dim) {
    string str;
    for (int i = 0; i < n_dim; i++) {
      str.append(1, char(65+cell[i]));
    }
    if (data.find(str) == data.end()) {
      cout << "Error!" << endl;
      cout << str << endl;
      exit(1);
    }
    return data[str]; 
  }
  int base = (1 << d);
  if (((query & base) == 0) && ((cuboid & base) == base)) {
    double res = 0;
    for (int i = 1; i <= card[d]; i++) {
      cell[d] = i;
      res += DFS_cuboid(query, cuboid, d+1, cell, data);
    }
    cell[d] = 0;
    return res;
  } else {
    return DFS_cuboid(query, cuboid, d+1, cell, data);
  } 
}

void DFS_query(int query, int cuboid, int d, int* cell, map<string, double>&
    data)
{
  if (d == n_dim) {
    double res = DFS_cuboid(query, cuboid, 0, cell, data);
    var_sum += fabs(res);
    var_n++;
    if (fabs(res) > var_max) var_max = fabs(res);
    return; 
  }
  int base = (1 << d);
  if ((query & base) == base) {
    for (int i = 1; i <= card[d]; i++) {
      cell[d] = i;
      DFS_query(query, cuboid, d+1, cell, data); 
    }
  } else {
    cell[d] = 0;
    DFS_query(query, cuboid, d+1, cell, data);
  }
}

int useCuboid(int query, int cuboid) {
  int base = 1;
  int res = 1;
  for (int d = 0; d < n_dim; d++) {
    bool in_query = (query & base);
    bool in_cuboid = (cuboid & base);
    if ((in_query) && (!in_cuboid)) return -1; // query is not in this cuboid
    if ((!in_query) && (in_cuboid)) res = res * card[d];
    base = base * 2;
  }
  return res;
}

bool cmp(CUBOID a, CUBOID b)
{
  return (a.num < b.num);
}
void exeQuery_opt(int query)
{
  // sort 
  vector<CUBOID> cuboid_num;
  cuboid_num.clear();
  for (int i = 0; i < n_select_cuboids; i++) {
    int num = useCuboid(query, select_cuboids[i]);
    if (num != -1) {
      CUBOID tmp;
      tmp.id = i;
      tmp.num = num;
      cuboid_num.push_back(tmp);
    }
  }
  sort(cuboid_num.begin(), cuboid_num.end(), cmp);
  // calculate each variance
  vector<double> var_sum_arr;
  vector<double> var_max_arr;
  vector<double> var_avg_arr;
  var_sum_arr.clear();
  var_max_arr.clear();
  var_avg_arr.clear();
  /*
  for (unsigned int i = 0; i < cuboid_num.size(); i++) {
  */
  for (unsigned int i = 0; i < 1; i++) {
    var_sum = 0;
    var_max = 0;
    var_n = 0;
    int cuboid = select_cuboids[cuboid_num[i].id];
    DFS_query(query, cuboid, 0, cell, data_cuboid);
    var_sum_arr.push_back(var_sum);
    var_max_arr.push_back(var_max);
    var_avg_arr.push_back(var_sum/var_n);
  }  
  // Use one cuboid
  // cout << "Opt Materialize \t";
  // cout << "Max=" << var_max_arr[0] << "\t";
  // cout << "Avg=" << var_avg_arr[0] << endl;
  
  // Use k cuboids 
  /*
  int min_k = 1;
  int min_num_sum = cuboid_num[0].num;
  for (unsigned int k = 1; k < cuboid_num.size(); k++) {
    int num_sum = 0;
    for (unsigned int i = 0; i < k; i++) {
      num_sum += cuboid_num[i].num; 
    }
    num_sum = num_sum / (k*k);
    if (num_sum < min_num_sum) {
      min_k = k;
      min_num_sum = num_sum;
    }
  }
  cout << "Opt Materalize (k=" << min_k << "):\t";
  double max = var_max_arr[0];
  double avg = var_avg_arr[0];
  for (int k = 1; k < min_k; k++) {
    if (var_max_arr[k] > max) max = var_max_arr[k];
    avg += var_avg_arr[k]; 
  }
  cout << "Max=" << max << "\t";
  cout << "Avg=" << avg/min_k << endl;
  */
}

void exeQuery_basecell(int query)
{
  var_sum = 0;
  var_max = 0;
  var_n = 0;
  
  // Use selected cuboids
  int cuboid = (1<<n_dim)-1;
  DFS_query(query, cuboid, 0, cell, data_basecell);
  // cout << "No materialize: \t";
  // cout << "Max=" << var_max << "\t";
  // cout << "Avg=" << var_sum/var_n << endl;
}

void exeQuery_all(int query)
{
  var_sum = 0;
  var_max = 0;
  var_n = 0;
  
  // Use selected cuboids
  int cuboid = query;
  DFS_query(query, cuboid, 0, cell, data_all);
  // cout << "Materialize all: \t";
  // cout << "Max=" << var_max << "\t";
  // cout << "Avg=" << var_sum/var_n << endl;
}

int query_size(int query)
{
	int ret=0;
	for (int i=0; i<n_dim; i++)
		if (query&(1<<i))
			ret++;
	return ret;
}

void exeQuery()
{
  ifstream fin;
  fin.open(file_query, ios::in);
  if (fin.fail()) {
    cout << "File does not exist!" << file_query << endl;
    exit(1);
  }
  char* query_str= new char[1000];
  cell = new int[n_dim];
  
  FILE *fout=fopen("../output.txt","w");
  double max1=0,max2=0,max3=0,sum1=0,sum2=0,sum3=0,cnt=0;
  for (int query=0; query<(1<<n_dim); query++)
  if (query_size(query)<=n_dim)
  {
	cout << query << endl;

	cnt++;

	exeQuery_opt(query);
	max1=max(max1,var_sum/var_n);
	sum1+=var_sum/var_n;
	//max1=max(max1,var_max);
	//sum1+=var_sum;

	exeQuery_basecell(query);
	max2=max(max2,var_sum/var_n);
	sum2+=var_sum/var_n;
	//max2=max(max2,var_max);
	//sum2+=var_sum;

	exeQuery_all(query);
	max3=max(max3,var_sum/var_n);
	sum3+=var_sum/var_n;
	//max3=max(max3,var_max);
	//sum3+=var_sum;

	//cnt+=var_n;
  }
  fprintf(fout,"%0.4lf\t%0.4lf\t%0.4lf\n",sum1/cnt,sum2/cnt,sum3/cnt);
  fprintf(fout,"%0.4lf\t%0.4lf\t%0.4lf\n",max1,max2,max3);
  fclose(fout);

  /*
  while (fin.getline(query_str, 1000)) {
    if (strlen(query_str)==0)
	  return;
    cout << "Query: " << query_str << endl;
    int query = stringToInt(query_str);
    exeQuery_opt(query);
    exeQuery_basecell(query);
    exeQuery_all(query);
  }
  */
  fin.close();
}
int main()
{
  readTableDim();
  readSelectedCuboids();
  readPublishData();
  exeQuery();
  return 0;
}
